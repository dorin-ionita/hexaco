(function() {
	//Declaration of module
	angular.module('questionDisplay',[
		'question',
		'quiz'
		]);
})();