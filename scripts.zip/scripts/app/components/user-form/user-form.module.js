(function (){
	//declaration of module
	angular.module('userForm',[
		'user',
		]);
})();