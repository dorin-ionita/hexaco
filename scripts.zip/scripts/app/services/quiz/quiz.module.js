(function() {
	//module declaration
	angular.module('quiz',[]);
})();