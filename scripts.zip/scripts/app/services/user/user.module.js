 (function () {
 	/*----------  Module declaration  ----------*/
 	angular.module('user',[]);
 })();