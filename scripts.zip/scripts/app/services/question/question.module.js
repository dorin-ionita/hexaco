(function() {
	//Declaration of module
	angular.module('question',[]);
})();