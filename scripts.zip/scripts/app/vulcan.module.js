(function (){
	//declaration of module
	angular.module('vulcan',[
		'questionDisplay',
		'userForm'
		]);
})();